# Student Profile App – Exercise Report

**Course:** Mobile Computing and Application Development (MSc IT-Mobile), Mount Kigali University
**Language:** Kotlin | **IDE:** Android Studio

---

## Part 1: Create and Run an Android Project

1. Open Android Studio → **New Project** → choose **Empty Views Activity**.
2. **Name:** `Student Profile App`
3. **Language:** `Kotlin`; Minimum SDK: API 24 or higher. Click **Finish** and wait for Gradle sync.
4. Create an emulator in **Device Manager** (e.g. Pixel 6, recent API image), or enable USB debugging on a physical phone.
5. Press **Run ▶** to launch the default app (a "Hello World!" screen).

**Achieved:** created a project, navigated Android Studio, and ran an application.

---

## Part 2: Explore the Android Project

| Component | Location | Purpose |
|---|---|---|
| **MainActivity** | `app/src/main/java/.../MainActivity.kt` | Kotlin class holding the screen's logic and event handling. |
| **User interface files** | `app/src/main/res/layout/activity_main.xml` | XML describing the screen layout (views and their positions). |
| **AndroidManifest.xml** | `app/src/main/AndroidManifest.xml` | Declares the app's components (activities), permissions, icon, label, theme and which activity launches first. |
| **Resources** | `app/src/main/res/` | Non-code assets: strings (`values/strings.xml`), colors, themes, images/icons (`drawable`, `mipmap`), layouts. |

### Exercise Question: What is the role of MainActivity in an Android application?

`MainActivity` is the **entry point and main screen controller** of the app. An Activity represents a single screen with a user interface. `MainActivity` is declared in `AndroidManifest.xml` with the `MAIN` action and `LAUNCHER` category, so Android starts it when the user opens the app. It:

- loads the layout in `onCreate()` using `setContentView()`;
- connects to the UI views (e.g. `findViewById`);
- handles user interaction, such as the Submit button's click;
- contains the logic that processes input and updates the display;
- participates in the Activity lifecycle (`onCreate`, `onStart`, `onResume`, `onPause`, `onStop`, `onDestroy`).

---

## Part 3: Design the User Interface

`activity_main.xml` contains:

1. Title: **Student Profile** (`TextView`)
2. Input for full name (`EditText`, `etFullName`)
3. Input for registration number (`EditText`, `etRegNumber`)
4. Input for programme (`EditText`, `etProgramme`)
5. **Submit** button (`Button`, `btnSubmit`)
6. Result text area (`TextView`, `tvResult`)

### Application Flow

Student enters information → Clicks Submit → Application processes information (reads and validates fields) → Results are displayed

### Expected Output

Input: Jean / 12345 / Information Technology

```
Welcome, Jean!
Registration Number: 12345
Programme: Information Technology
```

---

## How to Build It in Android Studio

1. Create the project as in Part 1.
2. Replace `MainActivity.kt` with the provided file (keep the `package` line matching your project).
3. Replace `res/layout/activity_main.xml` with the provided layout.
4. Replace `res/values/strings.xml` with the provided strings.
5. Check `AndroidManifest.xml` matches the provided one (Android Studio already generates it; keep your theme name).
6. Run the app and test with the example input.

## Screenshots to Include When Submitting

- New project settings (name and Kotlin)
- Project structure in the Project panel
- App running with empty form
- App showing the result after clicking Submit
