package com.example.studentprofileapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etFullName = findViewById<EditText>(R.id.etFullName)
        val etRegNumber = findViewById<EditText>(R.id.etRegNumber)
        val etProgramme = findViewById<EditText>(R.id.etProgramme)
        val btnSubmit = findViewById<Button>(R.id.btnSubmit)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        btnSubmit.setOnClickListener {
            val name = etFullName.text.toString().trim()
            val regNumber = etRegNumber.text.toString().trim()
            val programme = etProgramme.text.toString().trim()

            // Validate: all fields are required
            if (name.isEmpty() || regNumber.isEmpty() || programme.isEmpty()) {
                Toast.makeText(this, getString(R.string.error_fill_all), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Process the information and display the result
            tvResult.text = getString(R.string.result_format, name, regNumber, programme)
        }
    }
}
